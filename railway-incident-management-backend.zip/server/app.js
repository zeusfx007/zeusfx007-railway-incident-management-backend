const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();

const accidentsRouter = require('./routes/accidentRoute');
const theftRouter = require('./routes/theftRoute');
require('./connection')
const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(cors());


app.use('/api/accident', accidentsRouter);
app.use('/api/theft', theftRouter);


app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
