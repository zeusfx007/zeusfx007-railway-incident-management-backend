const mongoose = require('mongoose');
const { Accident, Theft} = require('./models/incidentModel')

mongoose.connect(
  process.env.MONGODB_URI,
  { useNewUrlParser: true, useUnifiedTopology: true }
)
  .then(async () => {
    console.log('connected')
  })
  .catch(e => console.log(e));


  mongoose.connection.once('open', async () => {
    const collections = await mongoose.connection.db.listCollections().toArray();
  
    if (!collections.some(collection => collection.name === 'thefts')) {
      await Theft.createCollection();
      console.log('Theft collection created.');
    }
  
    if (!collections.some(collection => collection.name === 'accidents')) {
      await Accident.createCollection();
      console.log('Accident collection created.');
    }
  
    console.log('Database setup complete.');
  });
