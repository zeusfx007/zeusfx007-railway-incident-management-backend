const mongoose = require('mongoose');

const accidentSchema = new mongoose.Schema({
  accident_type: { type: String, required: true },
  location: { type: String, required: true },
  description: { type: String, required: true },
  phone_no: { type: Number, required: true },
  timestamp: { type: Date, required: true, default: Date.now },
})

const theftSchema = new mongoose.Schema({
  theft_type: { type: String, require: true },
  theft_item: { type: String, require: true },
  location: { type: String, required: true },
  description: { type: String, required: true },
  phone_no: { type: Number, required: true },
  timestamp: { type: Date, required: true, default: Date.now },
})

const Accident = mongoose.model('accident', accidentSchema);
const Theft = mongoose.model('theft', theftSchema)



module.exports = { Accident, Theft };
