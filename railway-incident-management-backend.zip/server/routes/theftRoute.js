const express = require('express');
const router = express.Router();
const { Theft } = require('../models/incidentModel');
const decryptData = require('../crypto');

router.post('/', async (req, res) => {
    try {
        const { payload, key } = req.body;
        const data = decryptData(payload, key);
        const { theft_type, theft_item, location, description, phone_no } = JSON.parse(data);
        const newIncident = new Theft({
            theft_type: theft_type,
            theft_item: theft_item,
            location: location,
            description: description,
            phone_no: phone_no
        });
        const savedIncident = await newIncident.save();
        res.status(201).json(savedIncident);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const deletedtheft = await Theft.deleteOne({ _id: id });
        if (deletedtheft.deletedCount === 0) {
            return res.status(404).json({ message: 'No Data Found' });
        }
        res.status(200).json({ message: 'Theft deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.get('/', async (req, res) => {
    try {
        const phoneNo = req.query.phoneNo;
        const Theftdata = await Theft.find({ phone_no: phoneNo });
        if (!Theftdata) {
            return res.status(404).json({ message: 'No Data Found' });
        }
        res.status(200).json(Theftdata);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});
module.exports = router;