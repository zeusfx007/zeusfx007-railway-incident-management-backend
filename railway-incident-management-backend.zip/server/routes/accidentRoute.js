const express = require('express');
const router = express.Router();
const { Accident } = require('../models/incidentModel');
const decryptData = require('../crypto');



router.post('/', async (req, res) => {
  try {
    const { payload, key } = req.body;
    const data = decryptData(payload, key);
    const { accident_type, location, description, phone_no } = JSON.parse(data);
    const newIncident = new Accident({
      accident_type: accident_type,
      location: location,
      description: description,
      phone_no: phone_no,
    });
    const savedIncident = await newIncident.save();
    res.status(201).json(savedIncident);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }

});

router.delete('/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const deletedAccident = await Accident.deleteOne({ _id: id });
    if (deletedAccident.deletedCount === 0) {
      return res.status(404).json({ message: 'No Data Found' });
    }
    res.status(200).json({ message: 'Accident deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/', async (req, res) => {
  try {
    const phoneNo = req.query.phoneNo;
    const accident = await Accident.find({ phone_no: phoneNo });
    if (!accident) {
      return res.status(404).json({ message: 'No Data Found' });
    }
    res.status(200).json(accident);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/all', async (req, res) => {
  try {
    const phoneNo = req.query.phoneNo;
    const accident = await Accident.find();
    if (!accident) {
      return res.status(404).json({ message: 'Accident not found' });
    }
    res.status(200).json(accident);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});



module.exports = router;