const CryptoJS = require('crypto-js');
function decryptData(encryptedData, secretKey) {
    try {
      const bytes = CryptoJS.AES.decrypt(encryptedData, secretKey);
      const decryptedData = bytes.toString(CryptoJS.enc.Utf8);
      return decryptedData;
    } catch (error) {
      console.error("Decryption error:", error);
      return null;
    }
  }

  module.exports = decryptData;